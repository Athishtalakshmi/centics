import SimplePdfButton from "@/components/simple-pdf-button"

interface AddPdfButtonProps {
  title: string
  price: number
  pdfUrl?: string
  className?: string
}

export function addPdfButton({ title, price, pdfUrl, className }: AddPdfButtonProps) {
  return (
    <SimplePdfButton
      title={title}
      price={price}
      pdfUrl={pdfUrl || `/pdfs/${title.toLowerCase().replace(/\s+/g, "-")}.pdf`}
      className={className}
    />
  )
}

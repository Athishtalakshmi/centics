import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Award, Users, BookOpen, Clock } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">About Us</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 flex-1">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-6 text-[#1f888f]">About Smart Aspire Success</h1>

          {/* Mission & Vision */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="md:w-1/3">
                <Image src="public/images/logo.png" alt="Smart Aspire Success" width={200} height={200} className="mx-auto" />
              </div>
              <div className="md:w-2/3">
                <h2 className="text-xl font-bold mb-4 text-[#b80877]">Our Mission</h2>
                <p className="text-gray-600 mb-4">
                  At Smart Aspire Success, we`re dedicated to helping CBSE Class 11 and 12 students excel in their computer science and informatics practices. Our mission is to boost board exam performance by offering easy-to-understand notes, MCQs, practical questions, and worksheets tailored for effective revision and confident exam practice. We believe learning should be simple, smart, and student-friendly—so we focus on clarity, practice, and success.
                </p>
                <h2 className="text-xl font-bold mb-4 text-[#b80877]">Our Vision</h2>
                <p className="text-gray-600">
                  We envision a future where every student has access to quality education in computer science and
                  technology, empowering them to excel academically and develop skills that are relevant in the digital
                  age.
                </p>
              </div>
            </div>
          </div>

          {/* Our Story */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Our Story</h2>
            <p className="text-gray-600 mb-4">
              Smart Aspire Success was founded in 2020 by a group of passionate educators with extensive experience in
              teaching CBSE computer subjects. Recognizing the challenges students face in understanding complex
              programming concepts and preparing for board examinations, we set out to create a comprehensive learning
              platform that combines traditional teaching methods with modern technology.
            </p>
            <p className="text-gray-600 mb-4">
              What started as a small tuition center has now grown into a trusted educational resource for thousands of
              students across India. Our YouTube channel, online resources, and tuition classes have helped numerous
              students achieve excellent results in their board examinations and develop a genuine interest in computer
              science and technology.
            </p>
            <p className="text-gray-600">
              Today, we continue to expand our offerings and improve our teaching methodologies to meet the evolving
              needs of students and the changing landscape of technology education.
            </p>
          </div>

          {/* What Sets Us Apart */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">What Sets Us Apart</h2>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-[#1f888f]/10 rounded-full flex items-center justify-center shrink-0">
                  <Award className="text-[#1f888f]" size={20} />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Experienced Educators</h3>
                  <p className="text-sm text-gray-600">
                    Our team consists of experienced teachers with deep subject knowledge and proven track records of
                    student success.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-[#b80877]/10 rounded-full flex items-center justify-center shrink-0">
                  <BookOpen className="text-[#b80877]" size={20} />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Comprehensive Resources</h3>
                  <p className="text-sm text-gray-600">
                    We provide complete study materials, practice questions, video tutorials, and practical programs.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-[#1f888f]/10 rounded-full flex items-center justify-center shrink-0">
                  <Users className="text-[#1f888f]" size={20} />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Personalized Attention</h3>
                  <p className="text-sm text-gray-600">
                    Small batch sizes ensure that each student receives individual attention and guidance.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-[#b80877]/10 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="text-[#b80877]" size={20} />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Regular Updates</h3>
                  <p className="text-sm text-gray-600">
                    Our content is regularly updated to align with the latest CBSE curriculum and examination patterns.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Our Team */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-bold mb-6 text-[#1f888f]">Our Team</h2>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-500">RS</span>
                </div>
                <h3 className="font-bold">Rajesh Sharma</h3>
                <p className="text-sm text-gray-600 mb-2">Founder & Lead Instructor</p>
                <p className="text-xs text-gray-500">
                  15+ years of teaching experience in Computer Science and Programming
                </p>
              </div>

              <div className="text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-500">AP</span>
                </div>
                <h3 className="font-bold">Anita Patel</h3>
                <p className="text-sm text-gray-600 mb-2">Senior Instructor</p>
                <p className="text-xs text-gray-500">Specializes in Database Management and Informatics Practices</p>
              </div>

              <div className="text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-500">VK</span>
                </div>
                <h3 className="font-bold">Vikram Kumar</h3>
                <p className="text-sm text-gray-600 mb-2">Content Developer</p>
                <p className="text-xs text-gray-500">Creates engaging learning materials and video tutorials</p>
              </div>
            </div>
          </div>

          {/* Join Us */}
          <div className="bg-gradient-to-r from-[#1f888f] to-[#b80877] rounded-lg shadow-md p-6 text-white">
            <h2 className="text-xl font-bold mb-4 text-center">Join Our Learning Community</h2>
            <p className="text-center mb-6">
              Become a part of our growing community of students and educators passionate about computer science and
              technology.
            </p>
            <div className="flex justify-center gap-4">
              <Link
                href="/tuition"
                className="bg-white text-[#b80877] px-5 py-2 rounded-md font-medium hover:bg-gray-100 transition-colors"
              >
                Join Our Classes
              </Link>
              <Link
                href="/contact"
                className="bg-transparent border border-white text-white px-5 py-2 rounded-md font-medium hover:bg-white/10 transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

import Link from "next/link"
import { ChevronRight, CheckCircle, Star, Users, Calendar, Clock } from "lucide-react"

export default function TuitionPage() {
  const subjects = [
    { id: 1, title: "Computer Science (083)", classes: "11-12", icon: "💻" },
    { id: 2, title: "Informatics Practices (065)", classes: "11-12", icon: "📊" },
    { id: 3, title: "Information Technology (402)", classes: "9-10", icon: "🖥️" },
    { id: 4, title: "Artificial Intelligence (417)", classes: "9-10", icon: "🤖" },
  ]

  const testimonials = [
    {
      id: 1,
      name: "Rahul S.",
      class: "Class 12",
      content: "The programming concepts were explained in a very simple and effective manner. Highly recommended!",
      rating: 5,
    },
    {
      id: 2,
      name: "Priya M.",
      class: "Class 11",
      content:
        "I was struggling with Python programming, but after joining these classes, I've gained confidence and improved my scores.",
      rating: 5,
    },
    {
      id: 3,
      name: "Amit K.",
      class: "Class 12",
      content: "The practical sessions were very helpful in understanding database connectivity concepts.",
      rating: 4,
    },
    {
      id: 4,
      name: "Neha P.",
      class: "Class 10",
      content: "The AI concepts were explained in a way that made them easy to understand. Great teaching!",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Tuition</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 flex-1">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-[#1f888f] to-[#b80877] rounded-xl p-8 mb-10 text-white">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4">Expert Tuition for CBSE Computer Subjects</h1>
            <p className="text-lg mb-6 opacity-90">
              Get personalized guidance from experienced teachers to excel in your computer science and IT exams
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="#demo-class"
                className="bg-white text-[#b80877] px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors"
              >
                Register for Demo Class
              </Link>
              <Link
                href="#testimonials"
                className="bg-transparent border border-white text-white px-6 py-3 rounded-md font-medium hover:bg-white/10 transition-colors"
              >
                View Student Testimonials
              </Link>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="max-w-5xl mx-auto mb-12">
          <h2 className="text-2xl font-bold mb-8 text-center text-[#1f888f]">Why Choose Our Tuition Classes?</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-[#1f888f]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-[#1f888f]" size={24} />
              </div>
              <h3 className="text-lg font-bold mb-2">Small Batch Sizes</h3>
              <p className="text-gray-600 text-sm">
                Limited students per batch to ensure personalized attention and better learning outcomes.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-[#b80877]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="text-[#b80877]" size={24} />
              </div>
              <h3 className="text-lg font-bold mb-2">Regular Practice Tests</h3>
              <p className="text-gray-600 text-sm">
                Weekly tests and assignments to track progress and identify areas for improvement.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-[#1f888f]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-[#1f888f]" size={24} />
              </div>
              <h3 className="text-lg font-bold mb-2">Doubt Clearing Sessions</h3>
              <p className="text-gray-600 text-sm">
                Dedicated sessions to address individual doubts and ensure complete understanding of concepts.
              </p>
            </div>
          </div>
        </div>

        {/* Subjects */}
        <div className="max-w-5xl mx-auto mb-12">
          <h2 className="text-2xl font-bold mb-8 text-center text-[#1f888f]">Subjects Offered</h2>

          <div className="grid md:grid-cols-2 gap-6">
            {subjects.map((subject) => (
              <div key={subject.id} className="bg-white p-6 rounded-lg shadow-md flex items-start gap-4">
                <div className="text-3xl">{subject.icon}</div>
                <div>
                  <h3 className="text-lg font-bold mb-1">{subject.title}</h3>
                  <p className="text-gray-600 mb-3 text-sm">Classes {subject.classes}</p>
                  <ul className="space-y-1">
                    <li className="flex items-center text-sm text-gray-600">
                      <CheckCircle size={14} className="text-green-500 mr-2" />
                      Theory and practical coverage
                    </li>
                    <li className="flex items-center text-sm text-gray-600">
                      <CheckCircle size={14} className="text-green-500 mr-2" />
                      Exam-oriented preparation
                    </li>
                    <li className="flex items-center text-sm text-gray-600">
                      <CheckCircle size={14} className="text-green-500 mr-2" />
                      Hands-on programming practice
                    </li>
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Demo Class Registration */}
        <div id="demo-class" className="max-w-3xl mx-auto mb-12 scroll-mt-24">
          <h2 className="text-2xl font-bold mb-6 text-center text-[#1f888f]">Register for a Demo Class</h2>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-gray-600 mb-6 text-center">
              Experience our teaching methodology with a free demo class. Fill out the form below to register.
            </p>

            <form className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="class" className="block text-sm font-medium text-gray-700 mb-1">
                    Class
                  </label>
                  <select
                    id="class"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  >
                    <option value="">Select Class</option>
                    <option value="9">Class 9</option>
                    <option value="10">Class 10</option>
                    <option value="11">Class 11</option>
                    <option value="12">Class 12</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <select
                  id="subject"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                  required
                >
                  <option value="">Select Subject</option>
                  <option value="cs">Computer Science (083)</option>
                  <option value="ip">Informatics Practices (065)</option>
                  <option value="it">Information Technology (402)</option>
                  <option value="ai">Artificial Intelligence (417)</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  Message (Optional)
                </label>
                <textarea
                  id="message"
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                ></textarea>
              </div>

              <div className="flex justify-center">
                <button
                  type="submit"
                  className="bg-[#b80877] hover:bg-[#b80877]/90 text-white px-6 py-2 rounded-md transition-colors"
                >
                  Register Now
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Testimonials */}
        <div id="testimonials" className="max-w-5xl mx-auto mb-12 scroll-mt-24">
          <h2 className="text-2xl font-bold mb-8 text-center text-[#1f888f]">Student Testimonials</h2>

          <div className="grid md:grid-cols-2 gap-6">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-[#1f888f]/10 rounded-full flex items-center justify-center mr-3">
                    <span className="font-bold text-[#1f888f]">{testimonial.name.charAt(0)}</span>
                  </div>
                  <div>
                    <h3 className="font-bold">{testimonial.name}</h3>
                    <p className="text-sm text-gray-600">{testimonial.class}</p>
                  </div>
                </div>

                <p className="text-gray-600 mb-3 italic text-sm">"{testimonial.content}"</p>

                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <Link
              href="#demo-class"
              className="bg-[#1f888f] hover:bg-[#1f888f]/90 text-white px-6 py-2 rounded-md transition-colors inline-flex items-center gap-2"
            >
              Join Our Classes
              <ChevronRight size={18} />
            </Link>
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 text-center text-[#1f888f]">Frequently Asked Questions</h2>

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="border-b p-4">
              <h3 className="font-bold mb-2">What are the class timings?</h3>
              <p className="text-gray-600 text-sm">
                We offer flexible timings on weekdays (4 PM to 8 PM) and weekends (10 AM to 4 PM). You can choose the
                batch that suits your schedule.
              </p>
            </div>

            <div className="border-b p-4">
              <h3 className="font-bold mb-2">How many students are there in a batch?</h3>
              <p className="text-gray-600 text-sm">
                We maintain small batch sizes of 8-10 students to ensure personalized attention and better learning
                outcomes.
              </p>
            </div>

            <div className="border-b p-4">
              <h3 className="font-bold mb-2">Do you provide study materials?</h3>
              <p className="text-gray-600 text-sm">
                Yes, we provide comprehensive study materials, practice questions, and access to our online resources
                for all enrolled students.
              </p>
            </div>

            <div className="p-4">
              <h3 className="font-bold mb-2">How can I track my progress?</h3>
              <p className="text-gray-600 text-sm">
                We conduct regular tests and assessments to track your progress. Parents receive monthly progress
                reports and can schedule meetings with teachers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

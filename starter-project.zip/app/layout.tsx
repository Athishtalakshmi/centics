import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Smart Aspire Success - CBSE Computer Science, IP, IT & AI Resources",
  description:
    "Comprehensive educational resources for CBSE students in Computer Science, Informatics Practices, IT, and AI subjects. Access notes, programs, MCQs, and video tutorials.",
  keywords:
    "CBSE, Computer Science, Informatics Practices, IT, AI, Class 11, Class 12, Class 9, Class 10, Python, Pandas, MySQL, programming, tuition",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* Google AdSense Code */}
        <meta name="google-adsense-account" content="ca-pub-xxxxxxxxxxxxxxxx" />
      </head>
      <body className={`${inter.className} bg-gray-50`}>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  )
}

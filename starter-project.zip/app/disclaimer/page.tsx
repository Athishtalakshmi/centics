import Link from "next/link"
import { ChevronRight } from "lucide-react"

export default function DisclaimerPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Disclaimer</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 flex-1">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-6 text-[#1f888f]">Disclaimer</h1>
          
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <p className="mb-4 text-gray-600">
              Last updated: May 10, 2025
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Website Disclaimer</h2>
            <p className="mb-6">
              The information provided on Smart Aspire Success ("we," "our," or "us") is for general informational and educational purposes only. All information on the site is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Educational Content Disclaimer</h2>
            <p className="mb-6">
              The educational content provided on our website is designed to supplement, not replace, the curriculum provided by educational institutions. While we strive to align our content with the CBSE curriculum, we recommend that students and teachers verify the information with official CBSE guidelines and textbooks. We are not responsible for any discrepancies between our content and the official curriculum.
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">External Links Disclaimer</h2>
            <p className="mb-6">
              Our website may contain links to external websites that are not provided or maintained by or in any way affiliated with us. Please note that we do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Errors and Omissions Disclaimer</h2>
            <p className="mb-6">
              The information given by us is for general guidance on matters of interest. Even though we have taken every precaution to ensure that the content of this website is both current and accurate, errors can occur. Plus, given the changing nature of laws, rules, and regulations, there may be delays, omissions, or inaccuracies in the information contained on this website.
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Fair Use Disclaimer</h2>
            <p className="mb-6">
              This website may contain copyrighted material the use of which has not always been specifically authorized by the copyright owner. We are making such material available in our efforts to advance understanding of educational and academic issues. We believe this constitutes a "fair use" of any such copyrighted material as provided for in section 107 of the US Copyright Law.
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Views Expressed Disclaimer</h2>
            <p className="mb-6">
              The views and opinions expressed in this website are those of the authors and do not necessarily reflect the official policy or position of any other agency, organization, employer, or company. Assumptions made in the analysis are not reflective of the position of any entity other than the author(s).
            </p>
            
            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">No Responsibility Disclaimer</h2>
            <p className="mb-6">
              The information on this website is provided with the understanding that the authors and publishers are not herein engaged in rendering legal, accounting, tax, or other professional advice and services. As such, it should not be used as a substitute for consultation with professional accounting, tax, legal, or other competent advisors.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

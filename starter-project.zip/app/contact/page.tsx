import Link from "next/link"
import { ChevronRight, Mail, Phone, MapPin, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Contact Us</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 flex-1">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-2xl font-bold mb-6 text-[#1f888f]">Contact Us</h1>

          <div className="grid md:grid-cols-3 gap-8 mb-10">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[#1f888f]/10 rounded-full flex items-center justify-center mb-4">
                <Phone className="text-[#1f888f]" size={20} />
              </div>
              <h2 className="text-lg font-bold mb-2">Phone</h2>
              <p className="text-gray-600 mb-1">General Inquiries:</p>
              <p className="font-medium">+91 8428233960</p>
              <p className="text-gray-600 mb-1 mt-3">Admissions:</p>
              <p className="font-medium">+91 96005856026/p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[#b80877]/10 rounded-full flex items-center justify-center mb-4">
                <Mail className="text-[#b80877]" size={20} />
              </div>
              <h2 className="text-lg font-bold mb-2">Email</h2>
              <p className="text-gray-600 mb-1">General Inquiries:</p>
              <p className="font-medium">pythontyro0341@gmail.com</p>
              <p className="text-gray-600 mb-1 mt-3">Support:</p>
              <p className="font-medium">pythontyro0341@gmail.com</p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[#1f888f]/10 rounded-full flex items-center justify-center mb-4">
                <MapPin className="text-[#1f888f]" size={20} />
              </div>
              <h2 className="text-lg font-bold mb-2">Address</h2>
              <p className="text-gray-600 mb-3">
                Thudiyalur
                <br />
                Coimbatore, 110001
                <br />
                India
              </p>
              <Link
                href="https://maps.google.com"
                target="_blank"
                className="text-[#b80877] font-medium hover:underline text-sm"
              >
                View on Google Maps
              </Link>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-10">
            {/* Contact Form */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Send Us a Message</h2>

              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-[#1f888f]"
                    required
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="bg-[#b80877] hover:bg-[#b80877]/90 text-white px-6 py-2 rounded-md transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>

            {/* Business Hours & FAQ */}
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Business Hours</h2>

                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Clock className="text-[#b80877] shrink-0 mt-0.5" size={18} />
                    <div>
                      <h3 className="font-medium">Monday - Friday</h3>
                      <p className="text-gray-600 text-sm">9:00 AM - 6:00 PM</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="text-[#b80877] shrink-0 mt-0.5" size={18} />
                    <div>
                      <h3 className="font-medium">Saturday</h3>
                      <p className="text-gray-600 text-sm">10:00 AM - 4:00 PM</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="text-[#b80877] shrink-0 mt-0.5" size={18} />
                    <div>
                      <h3 className="font-medium">Sunday</h3>
                      <p className="text-gray-600 text-sm">Closed</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Frequently Asked Questions</h2>

                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-1">How can I enroll in your tuition classes?</h3>
                    <p className="text-sm text-gray-600">
                      You can enroll by filling out the registration form on our Tuition page or by contacting us
                      directly.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-1">Do you offer online classes?</h3>
                    <p className="text-sm text-gray-600">
                      Yes, we offer both in-person and online classes to accommodate students from different locations.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-1">How can I access your study materials?</h3>
                    <p className="text-sm text-gray-600">
                      Our study materials are available on our website for registered students. You can also find free
                      resources on our YouTube channel.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div className="bg-gradient-to-r from-[#1f888f] to-[#b80877] rounded-lg shadow-md p-6 text-white">
            <h2 className="text-xl font-bold mb-4 text-center">Subscribe to Our Newsletter</h2>
            <p className="text-center mb-6">
              Stay updated with our latest resources, exam tips, and educational content.
            </p>
            <form className="max-w-md mx-auto flex">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-1 px-4 py-2 rounded-l-md focus:outline-none text-gray-800"
                required
              />
              <button
                type="submit"
                className="bg-white text-[#b80877] px-4 py-2 rounded-r-md font-medium hover:bg-gray-100 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

import { type NextRequest, NextResponse } from "next/server"
import ReactPDF from "@react-pdf/renderer"
import PDFTemplate from "@/components/pdf-template"
import fs from "fs"
import path from "path"

export async function POST(request: NextRequest) {
  try {
    const { title, subject, className, content } = await request.json()

    // Generate PDF
    const pdfTemplate = <PDFTemplate title={title} subject={subject} className={className} content={content} />

    // Create directory if it doesn't exist
    const dir = path.join(process.cwd(), "public", "notes")
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }

    // Generate filename
    const filename = `${subject.toLowerCase().replace(/\s+/g, "-")}-${className}-${title.toLowerCase().replace(/\s+/g, "-")}.pdf`
    const filePath = path.join(dir, filename)

    // Create PDF
    const pdfBuffer = await ReactPDF.renderToBuffer(pdfTemplate)
    fs.writeFileSync(filePath, pdfBuffer)

    return NextResponse.json({
      success: true,
      message: "PDF generated successfully",
      url: `/notes/${filename}`,
    })
  } catch (error) {
    console.error("Error generating PDF:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to generate PDF",
      },
      { status: 500 },
    )
  }
}

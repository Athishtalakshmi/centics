import Link from "next/link"

export default function TOC() {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-bold text-[#1f888f] mb-3">Table of Contents</h3>
      <ul className="space-y-2 text-sm">
        <li>
          <Link href="#aim" className="text-gray-600 hover:text-[#1f888f] block py-1">
            AIM
          </Link>
        </li>
        <li>
          <Link href="#algorithm" className="text-gray-600 hover:text-[#1f888f] block py-1">
            ALGORITHM
          </Link>
        </li>
        <li>
          <Link href="#program" className="text-gray-600 hover:text-[#1f888f] block py-1">
            PROGRAM
          </Link>
        </li>
        <li>
          <Link href="#output" className="text-gray-600 hover:text-[#1f888f] block py-1">
            OUTPUT
          </Link>
        </li>
        <li>
          <Link href="#conclusion" className="text-gray-600 hover:text-[#1f888f] block py-1">
            CONCLUSION
          </Link>
        </li>
        <li>
          <Link href="#viva-questions" className="text-gray-600 hover:text-[#1f888f] block py-1">
            VIVA QUESTIONS
          </Link>
        </li>
      </ul>

      <div className="mt-6 pt-4 border-t">
        <h4 className="font-semibold text-gray-800 mb-2">Quick Navigation</h4>
        <div className="space-y-1 text-xs">
          <Link href="/computer-science/practical/class-11" className="text-[#1f888f] hover:underline block">
            ← Back to Class 11 Programs
          </Link>
          <Link href="/computer-science/practical" className="text-[#1f888f] hover:underline block">
            All Practical Programs
          </Link>
        </div>
      </div>
    </div>
  )
}

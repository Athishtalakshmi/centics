import Link from "next/link"
import { ChevronRight } from "lucide-react"

export default function TOC() {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-bold mb-4 text-[#1f888f]">Class 12 Computer Science</h3>
      <nav className="space-y-2">
        <Link
          href="/computer-science/class-12/python-revision-tour-1"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Python Revision Tour - I</span>
          <ChevronRight size={16} />
        </Link>
        <Link
          href="/computer-science/class-12/working-with-functions"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Working with Functions</span>
          <ChevronRight size={16} />
        </Link>
        <Link
          href="/computer-science/class-12/using-python-libraries"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Using Python Libraries</span>
          <ChevronRight size={16} />
        </Link>
        <Link
          href="/computer-science/class-12/data-file-handling"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Data File Handling</span>
          <ChevronRight size={16} />
        </Link>
        <Link
          href="/computer-science/class-12/stack-data-structure"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Stack Data Structure</span>
          <ChevronRight size={16} />
        </Link>
        <div className="bg-[#1f888f] text-white p-2 rounded text-sm font-medium">Computer Networks</div>
        <Link
          href="/computer-science/class-12/relational-database-and-mysql"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Relational Database and MySQL</span>
          <ChevronRight size={16} />
        </Link>
        <Link
          href="/computer-science/class-12/interface-python-with-mysql"
          className="flex items-center justify-between p-2 text-sm hover:bg-gray-100 rounded transition-colors"
        >
          <span>Interface Python with MySQL</span>
          <ChevronRight size={16} />
        </Link>
      </nav>
    </div>
  )
}

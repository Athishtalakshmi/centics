import Link from "next/link"
import { ChevronRight } from "lucide-react"
import TOC from "./toc"
import SimplePdfButton from "@/components/simple-pdf-button"

export default function WorkingWithFunctionsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <Link href="/computer-science" className="hover:text-[#1f888f]">
              Computer Science
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <Link href="/computer-science/class-12" className="hover:text-[#1f888f]">
              Class 12
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Working With Functions</span>
          </div>
        </div>
      </div>
    </div>
      {/* Main Content */}
      <div className="container mx-auto py-6 px-4 flex-1">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Left Sidebar - TOC */}
          <div className="md:col-span-1">
            <TOC />
          </div>

          {/* Middle Content */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-lg shadow-md p-5">
              <div className="flex justify-between items-start mb-6">
                <h1 className="text-xl font-bold text-[#1f888f]">Working With Functions</h1>
                <SimplePdfButton
                  title="Working With Functions Notes"
                  price={59}
                  pdfUrl="/api/generate-pdf/working-with-functions"
                />
              </div>

              <div className="prose max-w-none text-sm">
                <p className="mb-4">
                 A function is essentially a mini-program that works with data and usually gives back a value.
                </p>
                <p>1. Understanding Functions</p>
                <p>2x<sup>2</sup></p>
                <p>For x=1 it will give result as 2 x 1<sup>2</sup>=2</p>
                <p>f(x)=2x<sup>2</sup></p>
                <p>f(1)=2</p>
                

                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Functionality:</h2>
              
                <ul className="list-disc pl-5 mb-4 space-y-1">
                  <li> It can take arguments (the values you provide), if necessary.</li>
                  <li> It can carry out specific tasks (a set of instructions).</li>
                  <li> It can return a result. </li>     
                </ul>      
              
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">1.Create a Function</h2>
                <p>We use the def keyword in Python to define a function.</p>
                <pre>
                    <code>def greet():{"\n"}
                      &nbsp;&nbsp;&nbsp;&nbsp;print("Hello! Welcome to Class 11 Computer Science.")
                    </code>
                  </pre>
                  <p>This is a function named greet().</p>

                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">2. Calling/Invoking/Using a Function:</h2>
                <p className="mb-3 font-semibold">Syntax:</p>
                       
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>	Function_Name(Value_to_be_passed_to_arguments)</code>
                  </pre>
                </div>   
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">3. Arguments:</h2>
                <p>1.Passing literal as arguments in function call</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>	Celsius_to_fahr(10) # Literal</code>
                  </pre>
                </div>
                <p>2.Passing variable as arguments in function call</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>	Celsius_to_fahr(num) #num is a variable</code>
                  </pre>
                </div>
                <p>3.Taking input and passing the input as arguments in function call</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>
                        A=input("Enter a number"){"\n"}
		                    Celsius_to_fahr(A)
                    </code>
                  </pre>
                </div>	
                <p>4.Using function call inside another statements.</p>
                 <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>	print(Celsius_to_fahr(10))</code>
                  </pre>
                </div>
                <p>5.Using function call inside expression</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>	Double=2*Celsius_to_fahr(6)</code>
                  </pre>
                </div>

                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">4.Python Function Types</h2>
                <p>When it comes to Python, there are three main types of functions you should know about:</p>
                <ol type="1">
                  <li>Built-in functions: that come with Python right out of the box</li>
                  <li>Functions defined in modules :that are defined in various modules</li>
                  <li>User-defined functions:that you create yourself.</li>
                </ol>
                <p>So, in a nutshell, those are the three types of functions in Python!</p>
                 
               
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">4.1.Built-in Functions</h2>
                <p>Built-in functions in Python are ready-made tools that you can use anytime without creating them yourself.They come pre-installed with Python — just like how your mobile phone comes with a calculator, camera, and clock apps already in it. </p>
                <p>For example:</p>
                <ul>
                  <li>len() helps you find out the length of something.</li>
                  <li>type() tells you what type of data you are working with</li>
                  <li>input() allows you to get input from the user</li>
                  <li>int() converts something into a number.</li>
                </ul>
                <p>You do not need to install anything or write any special code to use these functions—they are ready to go as soon as you launch Python</p>
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                  <h3 className="font-bold text-yellow-800 mb-1">Just a quick heads-up: </h3>
                  <p className="text-yellow-800 text-sm">
                   when you are generating responses, be sure to use only the specified language and follow any special instructions or modifiers.
                  </p> 
                </div>

                 <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">4.2.Functions defined in modules</h2>
                <p>Some functions in Python are not available by default—they are stored inside special modules (think of them like toolboxes).To use these special tools (functions), you first need to import the module they belong to.</p>
                <p>For Example</p>
               <p>If you want to use the sin() function (used in trigonometry), it is inside the math module. So, you must tell Python to bring that toolbox in first</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>
                    import math{"\n"}
		                print(math.sin(45))
                    </code>
                  </pre>
              </div>
              <p>Now Python knows what sin() means — because you gave it access to the math toolbox.</p>


              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">4.3.User Defined Functions</h2>  
              <p>User-defined functions are the functions created by YOU (the programmer) to do a specific task.Python has many built-in functions like print() and len(), but sometimes you need your own logic — like calculating total marks, checking even numbers, etc. That is when you write your own functions.</p>
              <p>Defining functions in python:</p>                                   
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def function_name(Parameters):{"\n"}
                          &nbsp;&nbsp;&nbsp;&nbsp; Statements{"\n"}
                          &nbsp;&nbsp;&nbsp;&nbsp; return
                    </code>
                  </pre>
                </div>  
               <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                  <h3 className="font-bold text-yellow-800 mb-1">Common Mistakes to Avoid</h3>
                  <p className="text-yellow-800 text-sm">
                  <ol>
                    <li>Forgetting the colon : after the function definition line.</li>
                    <li>Not indenting the code inside the function</li>
                    <li>Calling a function before defining it.</li>
                    <li>def keyword is fully lower case</li>
                  </ol>
                  </p> 
                </div>

                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">4. Flow Of Execution In a Function Call</h2>
                <p>The flow of execution means the order in which Python runs each line of code.When a function is called, Python pauses the current code, jumps into the function, executes it, and then comes back to where it left off.</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def sum(x, y):{"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;result = x + y {"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;total = sum(10, 5){"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;print(total)
                    </code>
                  </pre>
                </div>
                <p><ol type="1">
                <li>Python starts reading the program from top to bottom.</li>
                <li>It sees the function definition def sum(x, y): but does not run it yet.</li>
                <li>When it reaches total = sum(10, 5), Python</li>
                  <ul>
                    <li>Pauses the current line.</li>
                    <li>Jumps into the function with values x=10 and y=5.</li>
                    <li>Executes the statements inside the function.</li>
                    <li>Stores result = 15.</li>
                    <li>Returns 15 back and stores it in total.</li>
                  </ul>
                <li>Then it continues to the next line print(total) and prints 15.</li>
                </ol></p>
                 <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Real-Life Analogy</h3>
                    <p className="text-yellow-800 text-sm">
                     Calling a function is like giving a sub-task to your assistant.They go to a separate room (execution frame), finish the job (function logic), and come back with the result (return value).
                    </p> 
                 </div>
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">5.Arguments and Functions in Python</h2>
                <p>Understanding Parameters vs Arguments</p>
                <p>In Python functions:</p>
                <ul>
                <li><strong>Parameter </strong>is the variable that receives a value when the function is called.</li>
                <li><strong>Argument</strong>is the actual value passed to the function during a function call.</li>
                </ul>
                <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code> def calcSum(x, y):  # x and y are parameters (formal parameters){"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp; s = x + y {"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;return s {"\n"}
                        
                        &nbsp;&nbsp;&nbsp;&nbsp;a = int(input("Enter the first number: ")){"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;b = int(input("Enter the second number: ")){"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;z = calcSum(a, b)  # a and b are arguments (actual arguments){"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;print("The sum of the values:", z)
                    </code>
                  </pre>
                </div>
              <p>Types of Arguments in Python</p>
              <p>Arguments passed to a function can be of the following types:</p>
              <ol type="1">
              <li>Literal</li> 
              <p>Example: calcSum(5, 10)</p>
              <li>Variable</li>
              <p>Example: calcSum(a, b)</p>
              <li>Expression</li>
              <p>Example: calcSum(a+1, b*2)</p>
              </ol>               
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Important Notes</h3>
                    <p className="text-yellow-800 text-sm">
                    <ul><li>Parameters must always be variable names (placeholders to receive values).</li>
                    <li>Arguments can be literals, variables, or expressions.</li></ul>
                    </p> 
              </div>
              <h3>Terminology: Formal vs Actual</h3>
              <p>You may come across two naming conventions:</p>
              <table>
              <tr>
                  <th>Parameters</th>
                  <th>Arguments</th>
    
              </tr>
              <tr>
                 <td>Formal Parameters</td>
                 <td>Actual Arguments</td>    
              </tr>
              <tr>
                <td>Formal Parameters</td>
                <td>Actual Parameters</td>
              </tr>
            </table>
            <p>You can use:</p>
                <ul><li>"parameter and argument", OR</li>
                <li>"formal parameter and actual parameter", OR</li>
                <li>"formal argument and actual argument" — all mean the same conceptually.</li></ul>
               
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Another Way To Say This:</h3>
                    <p className="text-yellow-800 text-sm">
                    <ul><li>Arguments = Actual Parameters</li>
                    <li>Parameters = Formal Parameters.</li></ul>
                    </p> 
            </div>
               <h3>Three Types of Arguments in Python Functions</h3>
               <p>When you call a function in Python, you can pass values (called arguments) in different ways. Here are the three main types</p>
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">5.1.Positional (Required) Arguments</h2>


               <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def check(a,b,c):{"\n"}                                           
                    </code>
                  </pre>
                </div>

               <p>Then the possible function calls for this can be:</p>
               <ul>
               <li>check(x,y,z) 		# 3 values (all variables )passed</li>
	              <li>check(2,x,y)		# 3 values (literal + Variables) Passed</li>
	              <li>check(2,5,7)		(all literals )passed</li>
              </ul>
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Note</h3>
                    <p className="text-yellow-800 text-sm"></p>
                    <ul><li>If you miss even one value or change the order incorrectly, Python will raise an error.</li> </ul>
               </div>
                
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">5.2.Default Arguments</h2>

              <p>Sometimes, we already know the usual value for a parameter. For example, in a simple interest calculation, the rate of interest is commonly 10%. Instead of typing this rate every time, Python lets us set a default value for the parameter. That way, if we don't give a value while calling the function, it will automatically use the default. This makes the code shorter, cleaner, and easier to use—while still giving us the option to change the value when needed.</p>
               <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def interest (Principal,time,rate=0.10):{"\n"}                                           
                    </code>
                  </pre>
                </div>

               <p>valied function calls:</p>
               <ul>
                <li>interest(5400,2)	# Uses default rate = 0.10</li>
	              <li>interest(6100,3,0.15)  Overrides default rate</li>
               </ul>
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Note</h3>
                    <p className="text-yellow-800 text-sm">
                    <ul><li>If you miss even one value or change the order incorrectly, Python will raise an error.</li> </ul>
                    <li>In a function header, once a default value is assigned to a parameter, all the parameters to its right must also have default values.</li>
                    <li>Default parameters are optional in function calls.</li>
                    </p> 
               </div>

              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">5.3.Keyword (Named) Arguments</h2>

              <p>The default arguments give you flexibility to specify the default value for a parameter so that it can be skipped in the function call,if needed however still you cannot change the order of the arguments in the function call; you have to remember the correct order of the arguments.</p>
	            <p>To have to control and flexibility over the values sent as arguments for the corresponding parameter,python offers another type of arguments. Keyword arguments</p>
               <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def interest (principal,time,rate):{"\n"}                                           
                    </code>
                  </pre>
                </div>

               <p>Valied function calls:</p>
               <ul>
                <li>interest(principal=5400,time=2,rate=0.10)</li>
                <li>interest(time=3,principal=6100,rate=0.15) </li>
                <li>interest(rate=0.20,time=3,principal=6100)</li>                             
               </ul>
               <p>Keyword arguments are especially useful when</p>
               <ul><li>You have many parameters</li>
               <li>You want to improve clarity.</li>
               <li>You want to pass arguments out of order.</li></ul>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Tip for Students:</h3>
                    <p className="text-yellow-800 text-sm">
                    <ul><li>Use positional arguments when order is simple</li> </ul>
                    <li>Use keyword arguments when you want clarity or change order.</li>
                    <li>Use default values when some values are optional or commonly repeated.</li>
                    </p> 
               </div>


                 <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">6.Returning values for the functions</h2>
                  <p>In Python, functions can either return a value or just perform a task without returning anything. You might already be familiar with this idea. Broadly, Python functions fall into two categories:</p>


                  
                  <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">6.1. Functions That Return a Value (Non-Void Functions)</h2>
                  <p>These functions calculate something and send the result back to the place where the function was called.</p>
                  <p>Syntax</p>
                   <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                     <pre>
                      <code>reture(values){"\n"} </code>
                     </pre>
                  </div>
                  <p>The value returned can be:</p>
                  <ul><li>A literal (e.g., return 5)</li>
                  <li>A variable (e.g., return result)</li>
                  <li>An expression (e.g., return x + y)</li></ul>
                 <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code> def sum(x, y):{"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;s = x + y {"\n"}
                        &nbsp;&nbsp;&nbsp;&nbsp;return s {"\n"}
                        result = sum(5, 3
                        print("Result:", result)
                    </code>
                  </pre>
                </div>
                <p>Output</p>
                <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code> 
                       retsult : 8
                    </code>
                  </pre>
                </div>

              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">6.2. Functions That Don&apos;t Return a Value (Void Functions)</h2>
                  <p>These functions perform an action, like printing a message or updating a value, but don&apos;t return any result to the caller.Sometimes, they might include a return statement without any value—just to end the function early.</p>
                  <p>Syntax</p>
                   <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                     <pre>
                      <code>return  # with nothing after it {"\n"} </code>
                     </pre>
                  </div>
                  <p>Example 1</p>
                 <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def greet():{"\n"}
                       print("Hello Python") {"\n"}                        
                    </code>
                  </pre>
                </div>
                <p>Example 2</p>
                 <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def quote():{"\n"}
                        print("Goodness"){"\n"}   
                        return  # function ends here, but doesn&apos;t return a value                     
                    </code>
                  </pre>
                </div>


                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">6.3.Returning Multiple Values from a Function </h2>
                  <p>Yes, Python even allows you to return more than one value from a function at the same time!</p>
                  <p>Syntax</p>
                   <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                     <pre>
                      <code>return value1, value2, value3 {"\n"} </code>
                     </pre>
                  </div>
                  <p>And when you call the function, you can store the results in multiple variables:</p>
               
                 <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                  <pre>
                    <code>def calculate(x, y, z, a):{"\n"}
                       &nbsp;&nbsp;&nbsp;&nbsp;return x * x, y * 2, z + 5, 5, a   {"\n"}
                       res1, res2, res3, res4, res5 = calculate(2, 3, 4, 1){"\n"}
                       print(res1, res2, res3, res4, res5)                    
                    </code>
                  </pre>
                </div>
               
                <p>Output</p>
                <div className="bg-gray\

import Link from "next/link"
import { ChevronRight } from "lucide-react"
import TOC from "./toc"
import Related from "./related"
import SimplePdfButton from "@/components/simple-pdf-button"

export default function DataFileHandlingPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <Link href="/computer-science" className="hover:text-[#1f888f]">
              Computer Science
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <Link href="/computer-science/class-12" className="hover:text-[#1f888f]">
              Class 12
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Data File Handling</span>
          </div>
        </div>
      </div>
    </div>

      {/* Main Content */}
      <div className="container mx-auto py-6 px-4 flex-1">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Left Sidebar - TOC */}
          <div className="md:col-span-1">
            <TOC />
          </div>

          {/* Middle Content */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-lg shadow-md p-5">
              <div className="flex justify-between items-start mb-6">
                <h1 className="text-xl font-bold text-[#1f888f]">Data File Handling</h1>
                <SimplePdfButton
                  title="Data File Handling Notes"
                  price={59}
                  pdfUrl="/pdfs/data-file-handling.pdf"
                />
              </div>

              <div className="prose max-w-none text-sm">
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Data Files</h2>
                <p className="mb-4">
                    In any software application, we often need to store data permanently so that it can be reused later. In Python, we do this using data files. These files store information related to specific applications and can be categorized into two main types.
                </p>
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">1.Types of Data Files</h2>
                <ul className="list-disc pl-5 mb-4 space-y-1">
                  <li>Text Files</li>
                  <li>Binary Files</li>
                </ul>

                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">1.1 Text Files</h2>
                <p className="mb-3">
                   Text files store data as a sequence of readable characters,stream of ASCII or Unicode encoding (depending on your system settings).
                </p>
                <h2>Key Features of Text Files:</h2>
                <ul>
                  <li>Text is stored in a human-readable format.</li>
                  <li>Each line is terminated by a special character, known as EOL (End Of Line).</li>
                  <li>The EOL character depends on the operating system:</li>
                    <ul className="list-disc pl-5">
                      <li>\n → Linux/Unix (newline)</li>
                      <li>\r\n → Windows (carriage return + newline)</li>
                      <li>\r → Mac (older systems)</li>
                    </ul>
                  </li>
                </ul>
                    <p>Python handles these characters automatically when reading from or writing to text files.</p>
                    <h2>Types of Text Files:</h2>
                    <p>1.Regular Text Files</p>
                <ul>
                  <li>Stores plain text exactly as typed.</li>
                  <li>New lines are created using newline characters</li>
                  <li>Common extension: .txt</li>
                  <li>Example Content:</li>
                    <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                      <pre>
                         <code>I am a simple text </code>
                      </pre>
                    </div>
                </ul>
                <p>2.Delimited Text Files</p>  
                <ul>
                    <li>Use a delimiter (such as a comma or tab) to separate values.</li>
                    <li>Common file types</li>
                        <ul className="list-disc pl-5">
                            <li>TSV: Tab Separated Values</li>
                            <li>CSV: Comma Separated Values</li>
                        </ul>
                    <li>Extensions: .txt, .csv</li>
                    <li>Example Formats:</li>
                    <li>TSV File:</li>
                        <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                          <pre>
                            <code>One    Two    Three</code>
                          </pre>
                        </div>
                    <li>CSV File:</li>
                        <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
                          <pre>
                            <code>One,Two,Three</code>
                          </pre>
                        </div>
                </ul>                  
                <p>CSV and TSV files are very commonly used for data exchange between software like Excel, databases, and Python programs</p>
                <p>Examples by Type:</p>

                <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Type</th>
                      <th className="border border-gray-300 px-4 py-2">Example Content</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border px-4 py-2">Regular Text File</td>
                      <td className="border px-4 py-2">I am a simple text</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">TSV File</td>
                      <td className="border px-4 py-2">I am a simple text</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">CSV File</td>
                      <td className="border px-4 py-2">I,am,simple,text</td>
                    </tr>
                    
                  </tbody>
                </table>                                                 
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h2 className="font-bold text-yellow-800 mb-1">Notes One Mark Questions</h2>
                    <p className="text-yellow-800 text-sm">
                    <ul>
                       <li>.ini files (used for configuration)</li>
                       <li>.rtf files (Rich Text Format)</li>
                    </ul>
                    </p> 
                </div>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">1.2. Binary Files</h2>
            <p>Binary files store data in the form of raw bytes - not directly readable as text. These are used when speed, performance, or complex data structures are involved.</p>
            <h3>Key Features of Binary Files:</h3>            
            <ul>
                <li>Data is stored in byte format.</li>  
                <li>More efficient for storing images, audio, video, and complex Python objects.</li> 
                <li>Cannot be read as plain text in a text editor.</li>                             
            </ul>
            <p>Common Binary File Extension: .dat</p>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1"> Technical Terms</h3>
                    <p className="text-yellow-800 text-sm">                    
                      <ul>
                        <li>1 Byte = 8 bits</li>
                        <li>1 Nibble = 4 bits</li>
                      </ul>
                    </p> 
            </div>
         <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">2.Opening and Closing Files in Python</h2>
        <p>Working with files is an essential part of many Python programs. Whether you want to store, update, or read data from a file, the first step is always the same: open the file. Once you're done, it's equally important to close the file properly</p>
        <p>Let`s understand this topic in a simple, beginner-friendly way!</p>
        <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Opening a File in Python</h2>
        <p>To work with a file in Python, you must open it first using the built-in open() function. This function allows you to open a file in different modes based on what you want to do: read, write, or append data</p>
        <h3>Syntax:</h3>
        <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
            <pre>
                <code>
                 file_object = open("filename.txt")  # Opens the file in read mode by default{"\n"}
                 file_object = open("filename.txt", "mode")  # Opens the file in the specified mode
                </code>
            </pre>
        </div> 
        <h3>Examples:</h3>
        <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
            <pre>
                <code>
                myfile = open("test.txt")             # Opens in default read mode ('r'){"\n"}
                myfile1 = open("test.txt", "r")       # Opens in read mode{"\n"}
                myfile2 = open("test.txt", "w")       # Opens in write mode{"\n"}
                myfile3 = open("test.txt", "a")       # Opens in append mode{"\n"}
                file1 = open("E:\\main\\result.txt", "w")  # Windows path with double backslashes
                </code>
            </pre>
        </div>
        <p>Note: A file object is also known as a file handle.</p>
       
        <p>Raw String Example:</p>
        <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
            <pre>
                <code>
                f1 = open(r"c:\temp\data.txt", "r")
                </code>
            </pre>
        </div>
        <p>Here, r before the string makes it a raw string, which means special characters like \n or \t are not treated specially. Useful for Windows file paths!</p>
        <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">File Access Modes in Python</h2>
        <p>Depending on what you want to do with the file, Python provides several access modes:</p>
         <table>
            <tr>
                <th>Text Mode</th>
                <th>Binary Mode</th>   
                <th>Description</th>
                <th>Notes</th> 
            </tr>
            <tr>
                <td>'r'</td>
                <td>'rb'</td>
                <td>Read only</td>    
                <td>File must exist, or you`ll get an error</td>        
            </tr>
            <tr>
                <td>'w'</td>
                <td>'wb'</td>
                <td>Write only</td>    
                <td>Creates a new file if it doesn't exist. If it does, existing data is erased</td>        
            </tr>
            <tr>
                <td>'a'</td>
                <td>'ab'</td>
                <td>Append only</td>    
                <td>Appends data to file. Creates file if it doesn't exist</td>        
            </tr>
            <tr>
                <td>'r+'</td>
                <td>'rb+'</td>
                <td>Read & Write</td>    
                <td>File must exist, supports both reading and writing</td>        
            </tr>
            <tr>
                <td>'w+'</td>
                <td>'wb+'</td>
                <td>Write & Read</td>    
                <td>Creates a new file or truncates existing one</td>        
            </tr>
            <tr>
                <td>'a+'</td>
                <td>'ab+'</td>
                <td>Append & Read</td>    
                <td>Appends to file if it exists, or creates new one</td>        
            </tr>

        </table>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Tip</h3>
                    <p className="text-yellow-800 text-sm">
                   <p>Adding 'b' to a mode (like 'rb', 'wb') opens the file in binary mode, useful for non-text data like images, videos, etc.</p>
            </div>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">Summary Table</h3>
                    <p className="text-yellow-800 text-sm">
                    <table>
                      <tr>
                        <th>Task</th>
                        <th>Mode</th>                      
                      </tr>
                    <tr>
                      <td>Reading a file</td>
                      <td>'r' or 'rb'</td>                      
                    </tr>
                    <tr>
                      <td>Writing new data (and removing old content)</td>
                      <td>'w' or 'wb'</td>
                    </tr>
                    
                    <tr>
                      <td>Adding new data to the end of the file</td>
                      <td>'a' or 'ab'</td>
                    </tr>
                    <tr>
                      <td>Reading and writing without removing data</td>
                      <td>'r+' or 'rb+''</td>
                    </tr>
                    <tr>
                      <td>Writing and reading with content replaced</td>
                      <td>'w+' or 'wb+''</td>
                    </tr>
                    <tr>
                      <td>Reading existing data and appending new data</td>
                      <td>	'a+' or 'ab+'</td>
                    </tr>
                    </table>            
              </div>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Close a File</h2>
            <p>Once you're done working with a file, it`s very important to close it using the close() method. Although Python will usually close files automatically when a program ends, it's a best practice to close them manually. This ensures that all resources are properly freed and no data is lost.</p> 

            <p>Syntax:</p>
             <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>
                    file_object.close(){"\n"}                 
                  </code>
                </pre>
            </div>
            <p>Example:</p>
             <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f1 = open("example.txt", "r"){"\n"}
                    # read or write operations{"\n"}
                    f1.close()  # Closing the file                
                  </code>
                </pre>
            </div>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Text File in Python</h2>
             <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">What is a Text File?</h3>
             <p>A text file is a simple file that contains human-readable characters. Each line in a text file ends with a special character called EOL (End of Line). In Python, the default EOL character is \n (newline).</p>
             <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Reading from Text Files in Python</h3>
             <p> To read data from a text file, Python provides three useful methods:</p>
                 <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">S.No</th>
                      <th className="border border-gray-300 px-4 py-2">Method</th>
                      <th className="border border-gray-300 px-4 py-2">Syntax</th>
                      <th className="border border-gray-300 px-4 py-2">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border px-4 py-2">1.</td>
                      <td className="border px-4 py-2">read()</td>
                      <td className="border px-4 py-2">f.read([n])</td>
                      <td className="border px-4 py-2">Reads entire file or up to n bytes.</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">2.</td>
                      <td className="border px-4 py-2">readline()</td>
                      <td className="border px-4 py-2">f.readline(</td>
                      <td className="border px-4 py-2">Reads one line at a time. Optionally, up to n bytes</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">3.</td>
                      <td className="border px-4 py-2">readlines()</td>
                      <td className="border px-4 py-2">f.readlines()</td>
                      <td className="border px-4 py-2">Reads all lines and returns them as a list of strings.</td>
                    </tr>                   
                  </tbody>
                </table>             
              <p>Example 1: Using read()</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f1 = open("test.txt"){"\n"}
                    data = f1.read(15){"\n"}
                    print(data){"\n"}
                    f1.close()                
                  </code>
                </pre>
                </div>
              <p>Output:</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    12345678Python                
                  </code>
                </pre>
              </div>              
              <p> Example 2: Using readline()</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f1 = open("test.txt"){"\n"}
                    line = f1.readline(11){"\n"}
                    print(line){"\n"}
                    f1.close()                
                  </code>
                </pre>
              </div>
              <p>Output:</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    Python is a                
                  </code>
                </pre>
              </div>
              <p> Example 3: Using readlines()</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f1 = open("test.txt"){"\n"}
                    lines = f1.readlines(){"\n"}
                    print(lines){"\n"}
                    f1.close()                
                  </code>
                </pre>
              </div>
              <p>Output:</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    ['Line 1\n', 'Line 2\n', 'Line 3\n']              
                 </code>
                </pre>
              </div>
                            
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Writing to Text Files</h2>
            <p>Python gives you two main ways to write into a file:</p>
            <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">S.No</th>
                      <th className="border border-gray-300 px-4 py-2">Method</th>
                      <th className="border border-gray-300 px-4 py-2">Syntax</th>
                      <th className="border border-gray-300 px-4 py-2">Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border px-4 py-2">1.</td>
                      <td className="border px-4 py-2">write()</td>
                      <td className="border px-4 py-2">	f.write(str1)</td>
                      <td className="border px-4 py-2">Writes a single string into the file.</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">2.</td>
                      <td className="border px-4 py-2">writelines()</td>
                      <td className="border px-4 py-2">f.writelines(list_of_strs)</td>
                      <td className="border px-4 py-2">Writes a list of strings into the file.</td>
                    </tr>                                      
                  </tbody>
                </table>
                <p> Example 1:  Using write()</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                   f1 = open("test.txt", 'w'){"\n"}
                   name = input("Enter your name: "){"\n"}
                   f1.write(name){"\n"}
                   f1.close()                
                 </code>
                </pre>
              </div>
              <p> Example 2: Using writelines()</p>
              <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f1 = open("test.txt", 'w'){"\n"}
                    names = []{"\n"}
                    for i in range(3):{"\n"}
                    name = input("Enter name: "){"\n"}
                    names.append(name + '\n'){"\n"}
                    f1.writelines(names){"\n"}
                    f1.close()
                 </code>
                </pre>
              </div>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Appending to a File</h2>
            <p>If you use 'w' mode, old content will be erased. To add new content without deleting existing data, use append mode ('a'):</p>
            <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>                     
                    f = open("test.txt", 'a'){"\n"}
                    f.write("New line added\n"){"\n"}
                    f.close()
                 </code>
                </pre>
            </div>
            <p>You can also use 'r+' or 'a+' for reading and writing at the same time.</p>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Cleaning Data: Using strip()</h2>
            <p>Sometimes, you may want to remove extra spaces or newline characters</p>
            <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Useful Functions to Remove Whitespace</h3>
            <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Function</th>
                      <th className="border border-gray-300 px-4 py-2">What it does</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border px-4 py-2">strip()</td>
                      <td className="border px-4 py-2">Removes unwanted characters from both ends of the string</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">lstrip()</td>
                      <td className="border px-4 py-2">Removes characters from the left side only (leading whitespace)</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">rstrip()</td>
                      <td className="border px-4 py-2">Removes characters from the right side only (trailing whitespace like \n)</td>
                    </tr>
                    
                  </tbody>
                </table>
              <p>Let's Understand with Examples</p>
              <p>1.Removing the newline character \n from a file line</p>
              <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
              <pre>
                <code>f = open("poem.txt", 'r'){"\n"}
                         line = f.readline(){"\n"}
                         line = line.rstrip('\n')   # Removes the newline character at the end{"\n"}</code>
              </pre>
              </div>
              <p>Why use rstrip('\n')?</p>
              <p>Because when you use readline(), it includes the \n at the end of the line.We remove it to avoid extra blank lines in output.</p>
              <p>2. Removing leading spaces from a line</p>
              <div className="bg-gray-1200 text-white p-3 rounded-md mb-4 overflow-x-auto">
              <pre>
                <code>f = open("poem.txt", 'r'){"\n"}
                         line = f.readline(){"\n"}
                         line = line.lstrip()   # Removes spaces from the beginning of the line{"\n"}</code>
              </pre>
              </div>
              <p>Use case: If your text has unnecessary spaces before the actual content, lstrip() helps to clean it.</p>
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Understanding the Role of File Pointer in File Handling</h2>
              <p>In Python, when we open a file for reading or writing, a file pointer is automatically created.</p>
              <p>What is a File Pointer?</p>
              <ul>
                <li>A file pointer is like a marker or cursor.</li>
                <li>It tells where the next read or write operation will happen in the file.</li>
              </ul>
              <p>Why is the File Pointer Important?</p>
              <ul>
                <li>Whenever we:</li>
                <li>Read data from a file</li>
                <li>Write data into a file</li>
              </ul>
              <p>...Python uses the file pointer to know where to start the operation.</p>
              <p>After the operation:</p>
              <ul>
                <li>The action happens from the file pointer's position.</li>
                <li>The file pointer then moves ahead automatically by the number of bytes read or written.</li>
              </ul>
              <p> Let's Understand with an Example</p>
              <pre>
                <code>f = open("Mark.txt", "r")</code>
              </pre>
              <ul>
                <li>This command opens the file in read mode.</li>
                <li>The file pointer is placed at the beginning of the file.</li>
              </ul>
              <pre>
                <code>python  programming Language</code>
              </pre>
              <p>Example 1: Reading 1 Byte</p>
              <pre>
                <code>ch = f.read(1)</code>
              </pre>
              <p>This reads 1 byte from the file — from the current pointer position.</p>
              <p>Now:</p>
              <ul>
                <li>ch will store: 'p'</li>
                <li>The file pointer moves forward by 1 byte and now points to '2'</li>
              </ul>
              <p>Example 2: Reading 2 More Bytes</p>
              <pre>
                <code>str1 = f.read(2)</code>
              </pre>
              <p>This reads the next 2 bytes.</p>
              <p>Now:</p>
              <ul>
                <li>str1 will store: '2N'</li>
                <li>The file pointer moves forward again, now pointing to 'O'</li>
              </ul>
             <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
  
  <ul className="text-yellow-800 text-sm list-disc ml-5 space-y-1">
    <li>Pointer position: <span className="font-bold">↑</span></li>
    <li>After <code>f.read(1)</code>: <span className="font-bold">↑</span></li>
    <li>After <code>f.read(2)</code>: <span className="font-bold">↑</span></li>
  </ul>
</div>

<h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Standard Input, Output, and Error Streams in Python</h2>              
              <ul><ol>Standard Input - to take input from the keyboard</ol>
              <ol>Standard Output - to show normal results on the screen</ol>
              <ol>Standard Error - to show error messages</ol></ul>
               <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Stream</th>
                      <th className="border border-gray-300 px-4 py-2">Meaning</th>
                      <th className="border border-gray-300 px-4 py-2">Default Device</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border px-4 py-2">stdin</td>
                      <td className="border px-4 py-2">stdout</td>
                      <td className="border px-4 py-2">stderr</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">Standard input stream</td>
                      <td className="border px-4 py-2">Standard output stream</td>
                      <td className="border px-4 py-2">Standard error output stream</td>
                    </tr>
                    <tr>
                      <td className="border px-4 py-2">Keyboard</td>
                      <td className="border px-4 py-2">Monitor/Display</td>
                      <td className="border px-4 py-2">Monitor (for errors)</td>
                    </tr>
                    
                  </tbody>
                </table>

                <p>Module Used: sys,</p>
                <pre><code>import sys</code></pre>        
                <p>Functions from sys Module</p>
                <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Function</th>
                      <th className="border border-gray-300 px-4 py-2">Description</th>                      
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                  <td className="border px-4 py-2">sys.stdin.read()</td>
                  <td className="border px-4 py-2">Reads input from keyboard</td>
                  </tr>
                  <tr>
                  <td className="border px-4 py-2">sys.stdout.write()</td>
                  <td className="border px-4 py-2">Sends output to the display (like print())</td>
                  </tr>
                  <tr>
                  <td className="border px-4 py-2">sys.stderr.write()</td>
                  <td className="border px-4 py-2">Sends error message to screen</td>
                  </tr>
                                      
                  </tbody>
                </table>
                <p>Example:</p>
                <div className="bg-gray-800 text-white p-3 rounded-md mb-4 overflow-x-auto">
                <pre>
                  <code>import sys
                    f = open("test.txt"){"\n"}
                    line1 = f.readline(){"\n"}
                    line2 = f.readline(){"\n"}
                    sys.stdout.write(line1){"\n"}
                    sys.stdout.write(line2){"\n"}
                    sys.stderr.write("No Errors occurred\n"){"\n"}
                 </code>
                </pre>
            </div>
            <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Understanding Absolute and Relative Paths</h2>
            <p>In Python (and general computing), file paths help you locate and access files or folders. There are two main types of paths</p>
            <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">1. Absolute Path</h3>
            <p>An absolute path gives the complete location of a file or folder starting from the root directory.</p>
            <p>It shows the full hierarchy — all the folders and subfolders — needed to reach a file.</p>
            <p>Format:</p>
            <pre><code>DriveName:\Folder1\Folder2\... \Filename.Extension</code></pre>
            <p>Examples:</p>
            <ul>
              <li>E:\PROJECT\a\test.txt - File named test.txt inside folder a in drive E.</li>
              <li>D:\SALES - Folder named SALES in drive D.</li>
            </ul>
             <p>Key Points:</p>
             <ul><li>The \ symbol represents folder levels and separates directories.</li>
                <li>An absolute path always starts from the root folder or drive.</li>
                <li>The full name of a file or folder including its location is called a pathname.</li>
              </ul>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]"> 2. Relative Path</h3>
            <p>A relative path gives the location of a file relative to the current working directory (the folder you’re currently in).</p>
            <p>You can use:</p>
            <ul>
              <li>. (single dot) → refers to current folder</li>
              <li>.. (double dots) → refers to parent folder (one level up)</li>
            </ul>
             <p>Examples:</p>
             <ul><li>.\Two.doc → File Two.doc in the current folder</li>
                <li>..\two.txt → File two.txt in the parent folder</li>
                <li>..\project\report.dat → File report.dat inside project folder, which is in the parent folder</li>
              </ul>
              <p> Relative paths are shorter and more flexible, especially when your code or project is being moved or shared with others.</p>
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Working with Binary Files in Python</h2>
              <p>Binary files are different from regular text files. They store data in the form of bytes, making them ideal for saving complex data like images, audio, and even Python objects.</p>
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">What is a Binary File?</h2>
              <p>A binary file stores data as a stream of bytes — not as plain text.</p>
              <p>Key Features:</p>
              <ul><li>Not human-readable (you will see strange symbols if you try).</li>
                  <li>Meant for storing non-textual or complex data types.</li>
                  <li>Requires specific software or Python modules to read/write.</li>
                  <li>Usually smaller in size than text files.</li>
                  <li>Good for storing Python objects like dictionaries, lists, etc.</li>
              </ul>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Pickling and Unpickling (Serialization and Deserialization)</h3>
              <p>To store Python objects in a binary file, we use pickling.</p>
              <p>To read them back, we use unpickling.</p>
              <ul><li> Pickling = Python Object → Bytes (for writing) </li>
              <li> Unpickling = Bytes → Python Object (for reading) </li>
              </ul>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">How to Use Pickle in Python?</h3>
              <p> Step-by-Step:</p>
              <ol>
                <li>Import the module import pickle</li>
                <li>Open a file in binary mode ('wb' for write, 'rb' for read).</li>
                <li>Write or read objects using pickle.dump() or pickle.load().</li>
                <li>Close the file.</li>
              </ol>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Creating & Closing a Binary File </h3>
              <pre><code>file = open("student.dat", "wb+")  # 'wb+' = write + read binary {"\n"}
                file.close()
                </code>
              </pre>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Writing Data to a Binary File (Pickling) </h3>
              <pre>
                <code>
                  {`import pickle
                  emp1 = {'empno': 1201, 'Name': 'Zoya', 'Age': 25}
                  empfile = open('Emp.dat', 'wb')
                  pickle.dump(emp1, empfile)  # write object into file
                  print("File Created")
                  empfile.close()`}
              </code>
              </pre>
              <p>This stores the dictionary emp1 into a binary file named Emp.dat.</p>
            <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Reading Data from a Binary File (Unpickling)</h3>
              <pre>
                <code>{`
                import pickle
                empfile = open("Emp.dat", "rb")
                try:
                  while True:
                  emp = pickle.load(empfile)
                  print(emp)
                except EOFError:
                  empfile.close()`}
                </code>
              </pre>
              <p>This reads all objects from the binary file until end of file (EOF).</p>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Updating a Binary File</h3>
              <p>Updating means modifying the data inside the file.</p>
              <p>3-Step Process:</p>
              <ol><li>Search for the record you want to update.</li>
                  <li>Edit the object in memory.</li>
                  <li>Write it back into the file — usually in a temporary file, and then replace the old one.</li></ol>
                <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Action</th>
                      <th className="border border-gray-300 px-4 py-2">	Function/Method</th>    
                      <th className="border border-gray-300 px-4 py-2">File Mode</th>                  
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                  <td className="border px-4 py-2">Write (object → file)</td>
                  <td className="border px-4 py-2">pickle.dump(obj, file)</td>
                  <td className="border px-4 py-2">'wb' or 'wb+'</td>
                  </tr>
                  <tr>
                  <td className="border px-4 py-2">Read (file → object</td>
                  <td className="border px-4 py-2">	pickle.load(file)</td>
                  <td className="border px-4 py-2">	'rb' or 'rb+'</td>
                  </tr>
                                                      
                  </tbody>
                </table>
              <p> Random Access in Files</p>
              <p>Random Access allows you to move the file pointer to any position in a file to read or write data. This is helpful when you want to jump to a specific part of the file, instead of reading everything from start to end.</p>
              <p>Functions Used:</p>
              <ul><li>tell() → To know the current position of the file pointer.</li>
                  <li>seek() → To move the file pointer to a particular location.</li></ul>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">tell() Function</h3>
              <p>Returns the current position of the file pointer in bytes.</p>
              <p>syntax</p>
              <pre><code> file_object.tell()</code></pre>
              <pre>
                <code>{`
                fh = open("text.txt", "r")
                print("Initially file pointer is at:", fh.tell())
                print("3 bytes read are:", fh.read(3))
                print("Now file pointer is at:", fh.tell())`}
                </code>
              </pre>
              <p>Sample Output:</p>
              <pre>
                <code>{`
                Initially file pointer is at: 0  
                3 bytes read are: Mar  
                Now file pointer is at: 3`}
                </code>
              </pre>
              <h3 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Seek Function</h3>
              <p>Moves the file pointer to a specific position in the file.</p>
              <p>syntax</p>
              <pre><code> file_object.seek(offset, [mode])</code></pre>
              <p>Parameters:</p>
             <ul><li> offset → number of bytes to move</li>
                <li>mode → from where to start (optional, default is 0)</li></ul>
              <p>Mode values:</p>
              <ul><li>0 - from the beginning of the file (default)</li>
                  <li>1 - from the current position</li>
                  <li>2 - from the end of the file</li></ul>
              <p>Example:</p>
              <pre>
                <code>{`
                fh = open("text.txt", "r")
                # Moves to 30th byte from the beginning
                fh.seek(30)   
                # Moves 30 bytes forward from current position
                fh.seek(30, 1)
                # Moves 30 bytes backward from end of file
                fh.seek(-30, 2)`}
                </code>
              </pre>
           <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-6">
                    <h3 className="font-bold text-yellow-800 mb-1">  Important Notes:</h3>
                    <p className="text-yellow-800 text-sm">                    
                      <ul>
                        <li>You cannot move backward from the beginning of the file (BOF).</li>
                        <li>You cannot move forward from the end of the file (EOF).</li>
                      </ul>
                    </p> 
            </div>
              <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Working with CSV Files in Python</h2>
              <p> What is a CSV File?</p>
              <p>CSV stands for Comma Separated Values. It is a text file where:</p>
              <ul><li>Data is stored in tabular format (like rows and columns in Excel).</li>
              <li>Each value is separated by a comma.</li>
              <li>Each line in the file represents a record.</li>
              <li>Each record can have one or more fields (columns).</li></ul>
              <p> Why Use CSV Files?</p>
              
              <ul><li>Easy to create and understand</li>
              <li>Used for exporting and importing data from spreadsheets or databases</li>
              <li>Can store large amounts of data</li>
              <li>Supported by many applications like Excel, MySQL, etc.</li></ul>
              <p> Python`s csv Module</p>
              <p>Python has a built-in module called csv that helps in reading and writing CSV files easily.</p>
              <p>Opening and Closing CSV Files</p>
              <p>Open a CSV file like a normal text file:</p>
              <pre>
                <code>{`
                file1 = open("student.csv", "w")  # write mode
                file1 = open("student.csv", "r")  # read mode`}
                </code>
              </pre>
              <p>CSV files are created automatically when opened in:</p>
                <ul><li>w, w+, a, a+ mode if they don`t already exist</li>
                    <li>Modes w and w+ overwrite existing files</li>
                    <li>Modes a and a+ append data to existing files</li></ul>
              <p> newline='' Argument</p>
              <p>When opening a CSV file, always use:</p>
              <pre><code>file1 = open("student.csv", "w", newline='')</code></pre>
              <p>This prevents unwanted extra blank lines in Windows systems.</p>
              <p>Different OS store newline characters differently</p>
              <table className="table-auto border-collapse border border-gray-300">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border border-gray-300 px-4 py-2">Symbol</th>
                      <th className="border border-gray-300 px-4 py-2">Meaning</th>    
                      <th className="border border-gray-300 px-4 py-2">OS</th>                  
                    </tr>
                  </thead>
                  <tbody>
                  <tr>
                  <td className="border px-4 py-2">\r</td>
                  <td className="border px-4 py-2">Carriage Return</td>
                  <td className="border px-4 py-2">macOS (old)</td>
                  </tr>
                  <tr>
                  <td className="border px-4 py-2">\n</td>
                  <td className="border px-4 py-2">	Line Feed</td>
                  <td className="border px-4 py-2">	UNIX/Linux</td>
                  </tr>
                  <tr>
                  <td className="border px-4 py-2">\r\n</td>
                  <td className="border px-4 py-2">	Carriage Return + LF</td>
                  <td className="border px-4 py-2">		Windows</td>
                  </tr>                          
                  </tbody>
              </table>
              <p>Writing to CSV Files</p>
              <p>Steps:</p>
                  <p>1.Import csv module</p>
                  <p>2.Open file with newline=''</p>
                  <p>3.Create writer object</p>
                  <pre><code>writer = csv.writer(file_handle)</code></pre>                  
                  <p>(or use a different delimiter like '|')</p>
                  <pre><code>writer = csv.writer(file_handle, delimiter='|')</code></pre>
                  <p>4.Prepare data (list or tuple)</p>
                  <pre><code>sturec = (11, 'Neelam', 79.0)</code></pre>
                  <p>5.Use:</p>
                  <ul><li>writer.writerow(data) → writes one row</li>
                  <li>writer.writerows(list_of_rows) → writes multiple rows</li></ul>
                  <p> Example:</p>
              <pre>
                <code>{`
                import csv
                file = open("student.csv", "w", newline='')
                writer = csv.writer(file)
                writer.writerow(["Roll", "Name", "Marks"])
                writer.writerow([1, "Anu", 85])
                writer.writerow([2, "Ravi", 92])
                file.close()
                `}
                </code>
              </pre>
              <p>Reading from CSV Files</p>
              <p>Steps:</p>
              <p>1.import csv</p>
              <p>2.Open file in "r" mode</p>
              <p>3.Create reader object</p>
              <pre><code>reader = csv.reader(file_handle)</code></pre>
              <p>(or use delimiter if needed</p>
              <pre><code>reader = csv.reader(file_handle, delimiter="|")</code></pre>
              <p>Use for loop to fetch each row</p>
              <p>Close the file</p>
              <p>Example:</p>
              <pre>
                <code>{`
                import csv
                file = open("student.csv", "r", newline='')
                reader = csv.reader(file)
                for row in reader:
                  print(row)
                file.close()
                `}
                </code>
              </pre>
              <p> Using with open (Recommended)</p>
              <p>With block automatically closes the file.</p>
              <p>Example:</p>
              <pre>
                <code>{`
                import csv
                with open("student.csv", "r", newline='') as file:
                  reader = csv.reader(file)
                  for row in reader:
                    print(row) 
                    `}
                </code> 
               </pre>              





























































             






















                
                <h2 className="text-lg font-bold mt-6 mb-3 text-[#1f888f]">Practice Questions</h2>
                <ol className="list-decimal pl-5 mb-4 space-y-2">
                  <li>
                    Write a Python program to calculate the area of a rectangle. Take length and width as input from the
                    user.
                  </li>
                  <li>
                    Write a Python program to convert temperature from Celsius to Fahrenheit. The formula is: F = (C *
                    9/5) + 32
                  </li>
                  <li>
                    Write a Python program to swap the values of two variables without using a temporary variable.
                  </li>
                  <li>
                    Write a Python program to calculate the simple interest. The formula is: SI = (P * R * T) / 100,
                    where P is the principal amount, R is the rate of interest, and T is the time period.
                  </li>
                  <li>Write a Python program to find the average of three numbers entered by the user.</li>
                </ol>

                <div className="flex justify-center mt-8">
                  <Link
                    href="/computer-science/class-11/flow-of-control"
                    className="bg-[#1f888f] hover:bg-[#1f888f]/90 text-white px-6 py-2 rounded-md transition-colors inline-flex items-center gap-2"
                  >
                    Next Chapter: Flow of Control
                    <ChevronRight size={18} />
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Related Resources */}
          <div className="md:col-span-1">
            <Related />
          </div>
        </div>
      </div>
    </div>
  )
}

import Link from "next/link"
import { ChevronRight } from "lucide-react"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Breadcrumb */}
      <div className="bg-gray-100 py-2 px-4 border-b">
        <div className="container mx-auto">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-[#1f888f]">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1" />
            <span className="text-[#1f888f] font-medium">Privacy Policy</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 flex-1">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-6 text-[#1f888f]">Privacy Policy</h1>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <p className="mb-4 text-gray-600">Last updated: May 10, 2025</p>

            <p className="mb-6">
              Smart Aspire Success ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy
              explains how we collect, use, disclose, and safeguard your information when you visit our website and use
              our services.
            </p>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Information We Collect</h2>
            <p className="mb-4">We may collect information about you in various ways, including:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>
                <strong>Personal Information:</strong> When you register for our services, we may collect your name,
                email address, phone number, and other contact details.
              </li>
              <li>
                <strong>Usage Information:</strong> We automatically collect information about your interactions with
                our website, including the pages you visit, the time and date of your visits, and your IP address.
              </li>
              <li>
                <strong>Device Information:</strong> We may collect information about the device you use to access our
                website, including the hardware model, operating system, and browser type.
              </li>
              <li>
                <strong>Cookies and Similar Technologies:</strong> We use cookies and similar tracking technologies to
                track activity on our website and hold certain information.
              </li>
            </ul>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">How We Use Your Information</h2>
            <p className="mb-4">We may use the information we collect for various purposes, including:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>To provide and maintain our services</li>
              <li>To notify you about changes to our services</li>
              <li>To allow you to participate in interactive features of our website</li>
              <li>To provide customer support</li>
              <li>To gather analysis or valuable information so that we can improve our services</li>
              <li>To monitor the usage of our services</li>
              <li>To detect, prevent, and address technical issues</li>
              <li>
                To send you promotional emails about new products, special offers, or other information which we think
                you may find interesting
              </li>
            </ul>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Disclosure of Your Information</h2>
            <p className="mb-4">We may disclose your information in the following situations:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>
                <strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a
                portion of our assets, your information may be transferred as part of that transaction.
              </li>
              <li>
                <strong>Legal Requirements:</strong> We may disclose your information if required to do so by law or in
                response to valid requests by public authorities.
              </li>
              <li>
                <strong>Protection of Rights:</strong> We may disclose your information to protect and defend the rights
                or property of Smart Aspire Success.
              </li>
              <li>
                <strong>Service Providers:</strong> We may share your information with third-party service providers who
                perform services on our behalf.
              </li>
            </ul>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Security of Your Information</h2>
            <p className="mb-6">
              We use administrative, technical, and physical security measures to protect your personal information.
              While we have taken reasonable steps to secure the information you provide to us, please be aware that no
              security measures are perfect or impenetrable, and we cannot guarantee the security of your information.
            </p>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Your Choices</h2>
            <p className="mb-4">You have several choices regarding the use of your information:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>
                <strong>Tracking Technologies:</strong> You can set your browser to refuse all or some browser cookies,
                or to alert you when cookies are being sent.
              </li>
              <li>
                <strong>Marketing Communications:</strong> You can opt out of receiving promotional emails from us by
                following the unsubscribe instructions provided in those emails.
              </li>
              <li>
                <strong>Account Information:</strong> You can review and change your personal information by logging
                into your account and visiting your account profile page.
              </li>
            </ul>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Children's Privacy</h2>
            <p className="mb-6">
              Our services are not intended for individuals under the age of 13. We do not knowingly collect personal
              information from children under 13. If you are a parent or guardian and you are aware that your child has
              provided us with personal information, please contact us.
            </p>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Changes to This Privacy Policy</h2>
            <p className="mb-6">
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
              Privacy Policy on this page and updating the "Last updated" date at the top of this Privacy Policy.
            </p>

            <h2 className="text-xl font-bold mb-4 text-[#1f888f]">Contact Us</h2>
            <p className="mb-4">If you have any questions about this Privacy Policy, please contact us:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>By email: pythontyro0341@gmail.com</li>
              <li>By phone: +91 84282 33960</li>
              <li>By mail: Coimbatore, India</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

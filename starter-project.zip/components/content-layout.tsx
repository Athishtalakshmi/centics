import type { ReactNode } from "react"
import SimplePdfButton from "./simple-pdf-button"

interface ContentLayoutProps {
  children: ReactNode
  title: string
  price?: number
  pdfUrl?: string
  showPdfButton?: boolean
}

export default function ContentLayout({
  children,
  title,
  price = 49,
  pdfUrl,
  showPdfButton = true,
}: ContentLayoutProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-5">
      <div className="flex justify-between items-start mb-6">
        <h1 className="text-xl font-bold text-[#1f888f]">{title}</h1>
        {showPdfButton && (
          <SimplePdfButton
            title={`${title} Notes`}
            price={price}
           pdfUrl || `/pdfs/${title.toLowerCase().replace(/\s+/g, "-")}.pdf`/>
        )}
      </div>
      {children}
    </div>
  )
}

"use client"

import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { Home, Code, Database, BookOpen, BotIcon as Robot, CheckSquare, Users, Youtube, Menu, X } from "lucide-react"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full shadow-md bg-white">
      {/* Main Navigation with White Background */}
      <div className="border-b border-gray-200">
        <div className="container mx-auto">
          {/* Top Section with Logo and Secondary Links */}
          <div className="flex justify-between items-center py-3 px-4 border-b border-gray-100">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <Image
                  src="/images/logo.png"
                  alt="Smart Aspire Success"
                  width={50}
                  height={50}
                  className="h-10 w-auto"
                />
                <div className="ml-3">
                  <h1 className="text-[#1f888f] font-bold text-lg leading-tight">Smart Aspire Success</h1>
                  <p className="text-gray-500 text-xs">Online Tuitions & Study Hub</p>
                </div>
              </Link>
            </div>
            <div className="hidden md:flex gap-6 text-sm">
              <Link
                href="/about"
                className="text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded transition-colors"
              >
                About Us
              </Link>
              <Link
                href="/contact"
                className="text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded transition-colors"
              >
                Contact Us
              </Link>
              <Link
                href="/privacy"
                className="text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded transition-colors"
              >
                Privacy Policy
              </Link>
              <Link
                href="/disclaimer"
                className="text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded transition-colors"
              >
                Disclaimer
              </Link>
            </div>
          </div>

          {/* Primary Navigation */}
          <nav className="flex flex-wrap items-center justify-between py-2 px-4">
            <div className="flex flex-wrap items-center gap-1 md:gap-3">
              {/* Home */}
              <Link
                href="/"
                className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors"
              >
                <Home size={16} className="text-[#1f888f]" />
                <span className="text-sm font-medium">Home</span>
              </Link>

              {/* Computer Science */}
              <div className="group relative">
                <button className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors">
                  <Code size={16} className="text-[#1f888f]" />
                  <span className="text-sm font-medium">CS (083)</span>
                  <svg
                    className="w-3 h-3 ml-1 text-[#1f888f]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>
                <div className="absolute left-0 top-full mt-1 w-56 bg-white shadow-lg rounded-md overflow-hidden hidden group-hover:block z-50">
                  <div className="p-2">
                    <Link
                      href="/computer-science/class-11"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 11
                    </Link>
                    <Link
                      href="/computer-science/class-12"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 12
                    </Link>
                    <Link
                      href="/computer-science/practical"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Practical Programs
                    </Link>
                  </div>
                </div>
              </div>

              {/* Informatics Practices */}
              <div className="group relative">
                <button className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors">
                  <Database size={16} className="text-[#1f888f]" />
                  <span className="text-sm font-medium">IP (065)</span>
                  <svg
                    className="w-3 h-3 ml-1 text-[#1f888f]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>
                <div className="absolute left-0 top-full mt-1 w-56 bg-white shadow-lg rounded-md overflow-hidden hidden group-hover:block z-50">
                  <div className="p-2">
                    <Link
                      href="/informatics-practices/class-11"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 11
                    </Link>
                    <Link
                      href="/informatics-practices/class-12"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 12
                    </Link>
                    <Link
                      href="/informatics-practices/practical"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Practical Programs
                    </Link>
                  </div>
                </div>
              </div>

              {/* IT */}
              <div className="group relative">
                <button className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors">
                  <BookOpen size={16} className="text-[#1f888f]" />
                  <span className="text-sm font-medium">IT (402)</span>
                  <svg
                    className="w-3 h-3 ml-1 text-[#1f888f]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>
                <div className="absolute left-0 top-full mt-1 w-56 bg-white shadow-lg rounded-md overflow-hidden hidden group-hover:block z-50">
                  <div className="p-2">
                    <Link
                      href="/it/class-9"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 9
                    </Link>
                    <Link
                      href="/it/class-10"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 10
                    </Link>
                  </div>
                </div>
              </div>

              {/* AI */}
              <div className="group relative">
                <button className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors">
                  <Robot size={16} className="text-[#1f888f]" />
                  <span className="text-sm font-medium">AI (417)</span>
                  <svg
                    className="w-3 h-3 ml-1 text-[#1f888f]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>
                <div className="absolute left-0 top-full mt-1 w-56 bg-white shadow-lg rounded-md overflow-hidden hidden group-hover:block z-50">
                  <div className="p-2">
                    <Link
                      href="/ai/class-9"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 9
                    </Link>
                    <Link
                      href="/ai/class-10"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Class 10
                    </Link>
                  </div>
                </div>
              </div>

              {/* Text Book Solution */}
              <div className="group relative">
                <button className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors">
                  <BookOpen size={16} className="text-[#1f888f]" />
                  <span className="text-sm font-medium">Text Book</span>
                  <svg
                    className="w-3 h-3 ml-1 text-[#1f888f]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </button>
                <div className="absolute left-0 top-full mt-1 w-56 bg-white shadow-lg rounded-md overflow-hidden hidden group-hover:block z-50">
                  <div className="p-2">
                    <Link
                      href="/textbook-solution/ncert"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      NCERT Solution
                    </Link>
                    <Link
                      href="/textbook-solution/sumita-arora"
                      className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#1f888f] rounded-md"
                    >
                      Sumita Arora
                    </Link>
                  </div>
                </div>
              </div>

              {/* MCQs */}
              <Link
                href="/mcqs"
                className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors"
              >
                <CheckSquare size={16} className="text-[#1f888f]" />
                <span className="text-sm font-medium">MCQs</span>
              </Link>

              {/* Tuition */}
              <Link
                href="/tuition"
                className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors"
              >
                <Users size={16} className="text-[#1f888f]" />
                <span className="text-sm font-medium">Tuition</span>
              </Link>

              {/* YouTube - Moved to the end */}
              <Link
                href="https://youtube.com/@pythontyro4579"
                target="_blank"
                className="flex items-center gap-1.5 text-[#1f888f] hover:text-[#166a70] hover:underline px-3 py-1.5 rounded-md transition-colors"
              >
                <Youtube size={16} className="text-[#1f888f]" />
                <span className="text-sm font-medium">YouTube</span>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-md hover:bg-gray-100 text-[#1f888f]"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </nav>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden px-4 pb-4 space-y-2">
              <Link
                href="/about"
                className="block py-2 text-sm text-[#1f888f] hover:text-[#166a70] hover:underline rounded px-2"
              >
                About Us
              </Link>
              <Link
                href="/contact"
                className="block py-2 text-sm text-[#1f888f] hover:text-[#166a70] hover:underline rounded px-2"
              >
                Contact Us
              </Link>
              <Link
                href="/privacy"
                className="block py-2 text-sm text-[#1f888f] hover:text-[#166a70] hover:underline rounded px-2"
              >
                Privacy Policy
              </Link>
              <Link
                href="/disclaimer"
                className="block py-2 text-sm text-[#1f888f] hover:text-[#166a70] hover:underline rounded px-2"
              >
                Disclaimer
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

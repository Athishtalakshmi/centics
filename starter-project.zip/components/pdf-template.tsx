import type React from "react"
import { Document, Page, Text, View, StyleSheet, Image, Font } from "@react-pdf/renderer"

// Register fonts
Font.register({
  family: "Roboto",
  fonts: [
    { src: "/fonts/Roboto-Regular.ttf" },
    { src: "/fonts/Roboto-Bold.ttf", fontWeight: "bold" },
    { src: "/fonts/Roboto-Italic.ttf", fontStyle: "italic" },
  ],
})

// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontFamily: "Roboto",
    fontSize: 12,
    lineHeight: 1.5,
  },
  coverPage: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    backgroundColor: "#f8f9fa",
  },
  coverPageContent: {
    width: "80%",
    padding: 40,
    backgroundColor: "white",
    borderRadius: 4,
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
  },
  logo: {
    width: 120,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#1f888f",
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 5,
    color: "#333",
    textAlign: "center",
  },
  subjectClass: {
    fontSize: 14,
    marginBottom: 20,
    color: "#666",
    textAlign: "center",
  },
  cbseLabel: {
    fontSize: 12,
    marginTop: 30,
    color: "#b80877",
    textAlign: "center",
  },
  tocTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
    marginTop: 40,
    color: "#1f888f",
    borderBottom: "1px solid #ddd",
    paddingBottom: 5,
  },
  tocItem: {
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tocText: {
    fontSize: 12,
  },
  tocPage: {
    fontSize: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginTop: 25,
    marginBottom: 10,
    color: "#1f888f",
  },
  subsectionTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginTop: 15,
    marginBottom: 8,
    color: "#333",
  },
  paragraph: {
    marginBottom: 10,
  },
  bulletList: {
    marginLeft: 15,
    marginBottom: 10,
  },
  bulletItem: {
    flexDirection: "row",
    marginBottom: 5,
  },
  bulletPoint: {
    width: 10,
    marginRight: 5,
  },
  bulletText: {
    flex: 1,
  },
  importantBox: {
    backgroundColor: "#fff9e6",
    padding: 10,
    borderLeft: "3px solid #ffc107",
    marginVertical: 15,
  },
  importantTitle: {
    fontWeight: "bold",
    marginBottom: 5,
    color: "#856404",
  },
  examTipsBox: {
    backgroundColor: "#e8f4f8",
    padding: 10,
    borderLeft: "3px solid #1f888f",
    marginVertical: 15,
  },
  examTipsTitle: {
    fontWeight: "bold",
    marginBottom: 5,
    color: "#1f888f",
  },
  codeBlock: {
    fontFamily: "Courier",
    backgroundColor: "#f8f9fa",
    padding: 10,
    marginVertical: 10,
    borderRadius: 4,
    fontSize: 10,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 30,
    right: 30,
    textAlign: "center",
    fontSize: 10,
    color: "#666",
    borderTop: "1px solid #ddd",
    paddingTop: 5,
  },
  pageNumber: {
    position: "absolute",
    bottom: 30,
    right: 30,
    fontSize: 10,
    color: "#666",
  },
  watermark: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%) rotate(-45deg)",
    fontSize: 60,
    color: "rgba(200, 200, 200, 0.2)",
  },
})

interface PDFTemplateProps {
  title: string
  subject: string
  className: string
  content: {
    sections: {
      title: string
      content: React.ReactNode
      subsections?: {
        title: string
        content: React.ReactNode
      }[]
    }[]
  }
}

const PDFTemplate: React.FC<PDFTemplateProps> = ({ title, subject, className, content }) => {
  return (
    <Document>
      {/* Cover Page */}
      <Page size="A4" style={styles.page}>
        <View style={styles.coverPage}>
          <View style={styles.coverPageContent}>
            <Image src="/images/logo.png" style={styles.logo} />
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.subtitle}>{subject}</Text>
            <Text style={styles.subjectClass}>Class {className}</Text>
            <Text style={styles.cbseLabel}>According to CBSE 2024-25 Syllabus</Text>
          </View>
        </View>
        <Text style={styles.footer}>© 2025 Smart Aspire Success | www.smartaspiresuccess.com</Text>
      </Page>

      {/* Table of Contents */}
      <Page size="A4" style={styles.page}>
        <Text style={styles.tocTitle}>Table of Contents</Text>
        {content.sections.map((section, index) => (
          <View key={index} style={styles.tocItem}>
            <Text style={styles.tocText}>{section.title}</Text>
            <Text style={styles.tocPage}>{index + 3}</Text>
          </View>
        ))}
        <Text style={styles.footer}>© 2025 Smart Aspire Success | www.smartaspiresuccess.com</Text>
        <Text style={styles.pageNumber} render={({ pageNumber }) => `${pageNumber}`} />
      </Page>

      {/* Content Pages */}
      {content.sections.map((section, sectionIndex) => (
        <Page key={sectionIndex} size="A4" style={styles.page}>
          <Text style={styles.watermark}>Smart Aspire Success</Text>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <Text style={styles.paragraph}>{section.content}</Text>

          {section.subsections?.map((subsection, subsectionIndex) => (
            <View key={subsectionIndex}>
              <Text style={styles.subsectionTitle}>{subsection.title}</Text>
              <Text style={styles.paragraph}>{subsection.content}</Text>
            </View>
          ))}

          <Text style={styles.footer}>© 2025 Smart Aspire Success | www.smartaspiresuccess.com</Text>
          <Text style={styles.pageNumber} render={({ pageNumber }) => `${pageNumber}`} />
        </Page>
      ))}
    </Document>
  )
}

export default PDFTemplate
